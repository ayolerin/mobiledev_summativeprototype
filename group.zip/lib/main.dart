import 'package:flutter/material.dart';
import 'package:flutterapp/groupapp/generatedsplashscreenwidget/GeneratedSplashScreenWidget.dart';
import 'package:flutterapp/groupapp/generatedrectangle82widget/GeneratedRectangle82Widget.dart';
import 'package:flutterapp/groupapp/generatedhomescreenwidget/GeneratedHomeScreenWidget.dart';
import 'package:flutterapp/groupapp/generatedproductdetailwidget/GeneratedProductDetailWidget.dart';
import 'package:flutterapp/groupapp/generatedsignupwidget/GeneratedSignupWidget.dart';
import 'package:flutterapp/groupapp/generatedloginwidget/GeneratedLoginWidget.dart';

void main() {
  runApp(groupApp());
}

class groupApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedSplashScreenWidget',
      routes: {
        '/GeneratedSplashScreenWidget': (context) =>
            GeneratedSplashScreenWidget(),
        '/GeneratedRectangle82Widget': (context) =>
            GeneratedRectangle82Widget(),
        '/GeneratedHomeScreenWidget': (context) => GeneratedHomeScreenWidget(),
        '/GeneratedProductDetailWidget': (context) =>
            GeneratedProductDetailWidget(),
        '/GeneratedSignupWidget': (context) => GeneratedSignupWidget(),
        '/GeneratedLoginWidget': (context) => GeneratedLoginWidget(),
      },
    );
  }
}
